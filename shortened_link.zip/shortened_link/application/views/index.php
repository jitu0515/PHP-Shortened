<!-- Author : Jitendra kumar -->
<!DOCTYPE html>
<html>
<head>
  <title>Shortened Link</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src='http://code.jquery.com/jquery-2.2.4.min.js'></script>
<script src='http://cdn.jsdelivr.net/jquery.validation/1.15.0/jquery.validate.min.js'></script>
  <style type="text/css">
  	*{
  		font-family: ubuntu;
  		letter-spacing: 1px;
  	}
  	.heading
  	{
  		font-size: 35px;
  		color: orange
  	}
  	.define
  	{
  		margin-top: 100px;
  		border-radius: 10px 10px 0px 0px;
  	}
  	#top-image {
			background:url('<?php echo base_url()?>/assests/back.jpg') -25px -50px;
			position:fixed ;
			top:0;
			width:100%;
			z-index:0;
			  height:100%;
			  background-size: calc(100% + 50px);
			}
  </style>
</head>
<body id="top-image">

	<div class="container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4 btn-primary define"><hr>
				<center><h3><span class="heading">M</span>ake your Link Short</h3></center><hr>

				<!-- Form Starts from here -->
				<form action="<?php echo base_url()?>get_url" method="post">
					<!-- I'm redirecting form action to the controller using URI Routing -->
					<!-- Find "get_url" in application/config/routes -->
					<div class="form-group">
						<input type="text" name="url" class="form-control" placeholder="#Enter #URL" id="url">
					</div>
					<div class="form-group">
						<input type="submit" name="submit" class="btn btn-danger form-control" value="Get Link">
					</div>
					<center><?php $this->session->flashdata("error")?></center>
					<hr>
				</form>
				<!-- End of Form -->


			</div>
		</div>
	</div>
<script type="text/javascript">
	// Start of jquery to get black background color into input box and vice versa
	$(document).ready(function(){
		$("#url").focus(function(){
			$(this).css("background-color","#333");
			$(this).css("color","#fff");
		});

		$("#url").blur(function(){
			$(this).css("background-color","#fff");
			$(this).css("color","#000");
		});
	});
	// End of jquery to get black background color into input box and vice versa



	// Start of Jquery to move background image with mouse point
	$(document).ready(function() {
			var movementStrength = 25;
			var height = movementStrength / $(window).height();
			var width = movementStrength / $(window).width();
			$("#top-image").mousemove(function(e){
			          var pageX = e.pageX - ($(window).width() / 2);
			          var pageY = e.pageY - ($(window).height() / 2);
			          var newvalueX = width * pageX * -1 - 25;
			          var newvalueY = height * pageY * -1 - 50;
			          $('#top-image').css("background-position", newvalueX+"px     "+newvalueY+"px");
			});
			});

	// End of Jquery to move background image with mouse point



	// Jquery Validation to check whether inserted input is URL or not
	var $form = $("form");
	$.validator.addMethod("letters", function(value, element) {
	  return this.optional(element) || value == value.match(/^[a-zA-Z\s]*$/);
	});
	$form.validate({
	  rules: {
	    url: {
	      required: true,
	      url:true
	    }
	  },
	  messages: {
	    url: "Enter correct URL"
	  },
	  submitHandler: function() {
	    $successMsg.show();
	  }
	});
</script>


</body>
</html>