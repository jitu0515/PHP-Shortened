<!-- Author : Jitendra kumar -->
<!DOCTYPE html>
<html>
<head>
  <title>Shortened Link</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style type="text/css">
  	*{
  		font-family: ubuntu;
  		letter-spacing: 1px;
  	}
  	.heading
  	{
  		font-size: 35px;
  		color: black;
  	}
  	.define
  	{
  		margin-top: 100px;
  		border-radius: 10px 10px 0px 0px;
  	}
  	.definelink
  	{
  		color: #000;
  		font-size: 15px;
  	}
	#top-image {
			background:url('<?php echo base_url()?>/assests/back.jpg') -25px -50px;
			position:fixed ;
			top:0;
			width:100%;
			z-index:0;
			  height:100%;
			  background-size: calc(100% + 50px);
			}
  </style>
</head>
<body id="top-image">

	
		
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4 btn-warning define"><hr>
				<center><h3><span class="heading">Y</span>our Link</h3></center><hr>
				<?php
				foreach ($get_link as $row) {
					$url = $row->url;
					?>
					<center>
						<a href="<?php echo $url?>" class="definelink" target="blank">http://jitendratest.com/<?php echo $row->shortened?></a><br><br>
					</center>
					<div class="form-group">
						<a href="<?php echo base_url()?>back" class="btn btn-primary form-control ">Back</a>
					</div>
					<hr>
					<?php
				}
				?>
			</div>
		</div>
	</div>
<script type="text/javascript">
	$(document).ready(function(){
		$("#url").focus(function(){
			$(this).css("background-color","#333");
			$(this).css("color","#fff");
		});

		$("#url").blur(function(){
			$(this).css("background-color","#fff");
			$(this).css("color","#000");
		});
	});

	$(document).ready(function() {
			var movementStrength = 25;
			var height = movementStrength / $(window).height();
			var width = movementStrength / $(window).width();
			$("#top-image").mousemove(function(e){
			          var pageX = e.pageX - ($(window).width() / 2);
			          var pageY = e.pageY - ($(window).height() / 2);
			          var newvalueX = width * pageX * -1 - 25;
			          var newvalueY = height * pageY * -1 - 50;
			          $('#top-image').css("background-position", newvalueX+"px     "+newvalueY+"px");
			});
			});
</script>
</body>
</html>