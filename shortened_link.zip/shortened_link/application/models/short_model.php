<?php
/**
* 
*/
class Short_model extends CI_Model
{
	// Start of function to insert path into database
	public function insert($table,$data)
	{
		return $this->db->insert($table,$data);
	}
	// End of function to insert path into database

	// Start of fetch Function to get the inserted URL
	public function fetch($select,$condition,$table)
	{
		$query = $this->db->select($select)
						  ->where($condition)
						  ->get($table);
		return $query->result();
	}
	// End of fetch function
}
?>