<?php
/**
* 
*/
class Short_controller extends CI_Controller
{
	
	// function to load index page
	public function index()
	{
		$this->load->view('index');
	}


	// Function to insert url into database and to fetch as well
	public function get_shortest_path()
	{
		$url = $this->input->post('url'); //We are receiving url from input box.

		$urlinput=$this->db->escape_str($url); //Here we are removing some unwanted strings.
		$id=rand(10000,99999); 				// TO get some random value.
		$shorturl=base_convert($id,20,36); //Return a string containing number.
		// Now we are preparing data to insert into the database
		$data = array(
			'rand_id'	=>	$id,
			'url'		=>	$urlinput,
			'shortened'	=>	$shorturl
		);
		// I'm providng table name here only, in which i want to insert
		$table="redirect";
		// I already loaded the model, using autoload file
		$inserted = $this->short_model->insert($table,$data);
		// now If data is inserted successfully then, I'm performing some fetching action's
		if($inserted)
		{
			$last_id 	=	$this->db->insert_id();
			$select		=	"*";
			$condition	=	array('id'	=>	$last_id);
			$table		=	"redirect";
			$data['get_link'] =   $this->short_model->fetch($select,$condition,$table);
			$this->load->view('view_link',$data);
		}
		else
		{
			// In case if URL is break then i set the flash message here
			$this->session->set_flashdata("error","Failed to get Short URL");
			return redirect('Short_controller/index');
		}

		
	}
}
?>